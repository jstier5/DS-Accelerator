library(tidyverse)
library(lubridate)

setwd('C:/Users/jstier/test-repo')
temp <- tempfile()
download.file('https://d396qusza40orc.cloudfront.net/exdata%2Fdata%2Fhousehold_power_consumption.zip',temp)
unzip(temp)

data <- read.table('./household_power_consumption.txt', header = TRUE, sep = ';', na = '?')
data2 <- filter(data, data$Date == '1/2/2007' | data$Date == '2/2/2007')
data2$DateTime <- paste(data2$Date, data2$Time)
data2$Date <- dmy(data2$Date)
data2$Time <- hms(data2$Time)
data2$DateTime <- dmy_hms(data2$DateTime)
# data2 <- data2[complete.cases(data2$Time),]

# Plot 1
png(filename = 'Plot1.png')
hist(data2$Global_active_power,
     main = 'Global Active Power',
     xlab= 'Global Active Power (kilowatts)',
     col = 'red')
dev.off()

# Plot 2
png(filename = 'Plot2.png')
plot(data2$DateTime, data2$Global_active_power, 
     type = 'l',
     ylab = 'Global Active Power (kilowatts)',
     xlab = '')
dev.off()

# Plot 3
png(filename = 'Plot3.png')
plot(data2$DateTime, data2$Sub_metering_1, 
     type = 'l', 
     col = 'black', 
     xlab = '',
     ylab = 'Energy sub metering')
lines(data2$DateTime, data2$Sub_metering_2, col = 'red')
lines(data2$DateTime, data2$Sub_metering_3, col = 'blue')
legend('topright', col = c('black', 'red', 'blue'),
       c('Sub_metering_1','Sub_metering_2','Sub_metering_3'),
       lwd = 1)
dev.off()

# Plot 4
png(filename = 'Plot4.png')
par(mfrow = c(2,2))
# top left
plot(data2$DateTime, data2$Global_active_power, 
     type = 'l',
     ylab = 'Global Active Power',
     xlab = '')
# top right
plot(data2$DateTime, data2$Voltage, 
     type = 'l',
     ylab = 'Voltage',
     xlab = 'datetime')
# bottom left
plot(data2$DateTime, data2$Sub_metering_1, 
     type = 'l', 
     col = 'black', 
     xlab = '',
     ylab = 'Energy sub metering')
lines(data2$DateTime, data2$Sub_metering_2, col = 'red')
lines(data2$DateTime, data2$Sub_metering_3, col = 'blue')
legend('topright', col = c('black', 'red', 'blue'),
       c('Sub_metering_1','Sub_metering_2','Sub_metering_3'),
       lwd = 1)
# bottom right
plot(data2$DateTime, data2$Global_reactive_power, 
     type = 'l',
     ylab = 'Global_reactive_power',
     xlab = 'datetime')
dev.off()